﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FormStructure
/// </summary>
public class FormListStructure
{
    public string HtmlTag;
    public string DataSourceTag;
    public string TopButtonTag;
    public string VariableDeclareCS;
    public string PopulateCS;
    public string InitCS;
    public string ValidateCS;
    public string FomattingCS;

    public FormListStructure()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}